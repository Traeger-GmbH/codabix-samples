try {
    $node_version = (node -v)
}
catch {
    "Node.js not found. Please install node.js from http://nodejs.org."
}
 "Installed node version: $node_version"

try {
    "Initializing npm..."
    npm init -y

    "Installing TypeScript"
    npm install typescript --save-dev

    "Initializing TypeScript"
    npx tsc --init

    "Editing tsconfig.json"
    (Get-Content tsconfig.json) -replace '^(\s*\/\/\s"sourceMap":\strue,)', '    "sourceMap": true,   ' | Set-Content tsconfig.json

    "Installing Codabix Debugging Runtime"
    npm install @traeger-industry/codabix-debug-runtime

    "Creating working directory and script file"
    New-Item -Name "src" -ItemType Directory
    New-Item -Path "src/testScript.ts" -ItemType File

    "Creating launch.json"
    New-Item -ItemType Directory -Force .vscode
    $launchJsonContent = @"
{
    "version": "0.2.0",
    "configurations": [
        {
            "type": "node",
            "request": "launch",
            "name": "Launch Program",
            "skipFiles": [
                "<node_internals>/**"
            ],
            "program": "`${workspaceFolder}\\src\\testScript.ts",
            "preLaunchTask": "tsc: build - tsconfig.json",
            "outFiles": [
                "`${workspaceFolder}/**/*.js"
            ]
        }
    ]
}
"@
    Out-File -FilePath ".vscode/launch.json" -InputObject $launchJsonContent -Encoding UTF8

    "Project setup successful! You can now close this window."
}
catch{
    Write-Error $_.Exception.Message
}

